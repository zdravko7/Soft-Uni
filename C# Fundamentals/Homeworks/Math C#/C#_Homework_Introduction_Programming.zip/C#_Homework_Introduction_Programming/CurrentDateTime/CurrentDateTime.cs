﻿using System;

	class CurrentDateTime
	{
		public static void Main(string[] args)
		{
			Console.WriteLine(DateTime.Now);
		}
	}
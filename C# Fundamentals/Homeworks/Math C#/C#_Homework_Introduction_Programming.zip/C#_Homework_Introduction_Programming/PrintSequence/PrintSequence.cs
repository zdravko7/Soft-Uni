﻿//Write a program that prints the first 10 members of the sequence: 2, -3, 4, -5, 6, -7, ...

using System;

class PrintSequence
{
	public static void Main(string[] args)
	{
		int result = 2;
		
		Console.Write("The first 1000 results of the given sequence are: " + result + " ");
		
		for (int i = 0; i < 9; i++)
			
		{
			if (result > 0)
			{
				
				result = ((result + 1) * -1);
			
			}
			else
			{
				result = ((result - 1) * -1);
				
			}
	
			Console.Write(result + " ");
			
		}
		
		Console.ReadKey();
		
	}
}
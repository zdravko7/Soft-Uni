﻿using System;

namespace HelloCSharp
{
	class HelloCSharp
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello C#");
		}
	}
}
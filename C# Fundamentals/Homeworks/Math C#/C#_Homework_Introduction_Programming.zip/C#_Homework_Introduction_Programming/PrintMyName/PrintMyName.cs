﻿
using System;

	class PrintMyName
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Zdravko");
			
		}
	}
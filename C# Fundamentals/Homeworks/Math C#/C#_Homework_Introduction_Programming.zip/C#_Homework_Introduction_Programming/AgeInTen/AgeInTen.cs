﻿//This program tells you how old you will be in 10 years

using System;

namespace AgeInTen
{
	class AgeInTen
	{
		public static void Main(string[] args)
		{
			Console.Write("Please input your age: ");
			int age = int.Parse(Console.ReadLine());
			
			int futureAge = age + 10;
			
			Console.WriteLine("Your age in 10 years will be: " + futureAge + " years");
			Console.ReadKey();
		}
	}
}
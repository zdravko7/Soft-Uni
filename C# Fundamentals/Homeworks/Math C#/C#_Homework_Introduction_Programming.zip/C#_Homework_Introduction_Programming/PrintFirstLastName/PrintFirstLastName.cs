﻿
using System;

	class PrintFirstLastName
	{
		public static void Main(string[] args)
		{
			Console.WriteLine(Math.Sqrt(12345));
			
			Console.ReadKey();
		}
	}